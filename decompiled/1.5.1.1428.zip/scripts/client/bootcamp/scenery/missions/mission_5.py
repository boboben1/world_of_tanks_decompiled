# uncompyle6 version 3.3.3
# Python bytecode 2.7 (62211)
# Decompiled from: Python 2.7.13 (v2.7.13:a06454b1afa1, Dec 17 2016, 20:53:40) [MSC v.1500 64 bit (AMD64)]
# Embedded file name: scripts/client/bootcamp/scenery/missions/mission_5.py
from constants import ARENA_PERIOD
from helpers.CallbackDelayer import CallbackDelayer
from bootcamp.scenery.AbstractMission import AbstractMission

class Mission5(AbstractMission):

    def __init__(self, assistant):
        super(Mission5, self).__init__(assistant)
        self.__musicCallback = CallbackDelayer()

    def start(self):
        super(Mission5, self).start()
        self.playSound2D('vo_bc_main_task')
        self.playSound2D('bc_main_tips_task_start')

    def _onPeriodChange(self, *args):
        super(Mission5, self)._onPeriodChange(*args)
        if args[0] == ARENA_PERIOD.BATTLE:
            self._playCombatMusic()