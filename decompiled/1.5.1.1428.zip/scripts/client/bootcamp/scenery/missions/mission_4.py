# uncompyle6 version 3.3.3
# Python bytecode 2.7 (62211)
# Decompiled from: Python 2.7.13 (v2.7.13:a06454b1afa1, Dec 17 2016, 20:53:40) [MSC v.1500 64 bit (AMD64)]
# Embedded file name: scripts/client/bootcamp/scenery/missions/mission_4.py
import BigWorld
from bootcamp.scenery.AbstractMission import AbstractMission

class Mission4(AbstractMission):
    _combatMusicDelayTime = 3.0

    def __init__(self, assistant):
        self._combatMusicTriggered = False
        self._callbackID = None
        super(Mission4, self).__init__(assistant)
        return

    def start(self):
        super(Mission4, self).start()
        self.playSound2D('vo_bc_main_task')
        self.playSound2D('bc_main_tips_task_start')
        self._avatar.muteSounds(('crew_member_contusion', 'track_destroyed', 'fire_started',
                                 'gunner_killed'))

    def onEnemyObserved(self, isObserved):
        if not self._combatMusicTriggered and self._callbackID is None:
            self._combatMusicTriggered = True
            self._callbackID = BigWorld.callback(self._combatMusicDelayTime, self._playCombatMusic)
        return

    def stop(self):
        self._avatar.muteSounds(())
        if self._callbackID:
            BigWorld.cancelCallback(self._callbackID)
            self._callbackID = None
        return

    def _playCombatMusic(self):
        super(Mission4, self)._playCombatMusic()
        self._callbackID = None
        return