# uncompyle6 version 3.3.3
# Python bytecode 2.7 (62211)
# Decompiled from: Python 2.7.13 (v2.7.13:a06454b1afa1, Dec 17 2016, 20:53:40) [MSC v.1500 64 bit (AMD64)]
# Embedded file name: scripts/client/bootcamp/scenery/TriggerListener.py
import TriggersManager

class TriggerListener(TriggersManager.ITriggerListener):

    def __init__(self, mission):
        super(TriggerListener, self).__init__()
        self._mission = mission
        TriggersManager.g_manager.addListener(self)

    def destroy(self):
        self._mission = None
        TriggersManager.g_manager.delListener(self)
        return

    def onTriggerActivated(self, params):
        self._mission.onTriggerActivated(params)

    def onTriggerDeactivated(self, params):
        self._mission.onTriggerDeactivated(params)