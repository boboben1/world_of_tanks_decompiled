# uncompyle6 version 3.3.3
# Python bytecode 2.7 (62211)
# Decompiled from: Python 2.7.13 (v2.7.13:a06454b1afa1, Dec 17 2016, 20:53:40) [MSC v.1500 64 bit (AMD64)]
# Embedded file name: scripts/client/bootcamp/states/StateOutroVideo.py
from AbstractState import AbstractState
from bootcamp.states import STATE
from gui.Scaleform.daapi.settings.views import VIEW_ALIAS
from gui.shared import EVENT_BUS_SCOPE
from gui.shared import events
from gui.shared import g_eventBus
_OUTRO_VIDEO_PATH = 'videos/_bootcampFinish.usm'

class StateOutroVideo(AbstractState):

    def __init__(self):
        super(StateOutroVideo, self).__init__(STATE.OUTRO_VIDEO)

    def handleKeyEvent(self, event):
        pass

    def _doActivate(self):
        g_eventBus.handleEvent(events.LoadViewEvent(VIEW_ALIAS.BOOTCAMP_OUTRO_VIDEO, None, self._getOutroVideoData()), EVENT_BUS_SCOPE.LOBBY)
        return

    def _getOutroVideoData(self):
        return {'video': _OUTRO_VIDEO_PATH}

    def _doDeactivate(self):
        pass