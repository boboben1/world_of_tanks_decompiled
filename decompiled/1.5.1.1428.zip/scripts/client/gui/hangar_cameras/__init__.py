# uncompyle6 version 3.3.3
# Python bytecode 2.7 (62211)
# Decompiled from: Python 2.7.13 (v2.7.13:a06454b1afa1, Dec 17 2016, 20:53:40) [MSC v.1500 64 bit (AMD64)]
# Embedded file name: scripts/client/gui/hangar_cameras/__init__.py
from skeletons.gui.hangar_cameras import IHangarCameraSounds
__all__ = ('getHangarCamerasConfig', )

def getHangarCamerasConfig(manager):
    from gui.hangar_cameras.hangar_camera_sounds import HangarCameraSounds
    ctrl = HangarCameraSounds()
    ctrl.init()
    manager.addInstance(IHangarCameraSounds, ctrl, finalizer='fini')