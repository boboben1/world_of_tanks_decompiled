# uncompyle6 version 3.3.3
# Python bytecode 2.7 (62211)
# Decompiled from: Python 2.7.13 (v2.7.13:a06454b1afa1, Dec 17 2016, 20:53:40) [MSC v.1500 64 bit (AMD64)]
# Embedded file name: scripts/client/gui/impl/backport/backport_time_utils.py
import time
from gui.impl.backport import text
from helpers import time_utils

def getTillTimeStringByRClass(timeValue, stringRClass, isRoundUp=False):
    gmtime = time.gmtime(timeValue)
    if isRoundUp and gmtime.tm_sec > 0:
        timeValue += time_utils.ONE_MINUTE
        gmtime = time.gmtime(timeValue)
    if timeValue >= time_utils.ONE_DAY:
        fmtKey = 'days'
        gmtime = time.gmtime(timeValue - time_utils.ONE_DAY)
    else:
        if timeValue >= time_utils.ONE_HOUR:
            fmtKey = 'hours'
        else:
            if timeValue >= time_utils.ONE_MINUTE:
                fmtKey = 'min'
            else:
                fmtKey = 'lessMin'
    fmtValues = {'day': str(time.struct_time(gmtime).tm_yday), 
       'hour': time.strftime('%H', gmtime), 
       'min': time.strftime('%M', gmtime), 
       'sec': time.strftime('%S', gmtime)}
    return text(stringRClass.dyn(fmtKey)(), **fmtValues)