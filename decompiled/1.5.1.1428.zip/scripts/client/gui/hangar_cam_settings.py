# uncompyle6 version 3.3.3
# Python bytecode 2.7 (62211)
# Decompiled from: Python 2.7.13 (v2.7.13:a06454b1afa1, Dec 17 2016, 20:53:40) [MSC v.1500 64 bit (AMD64)]
# Embedded file name: scripts/client/gui/hangar_cam_settings.py
from account_helpers.settings_core.options import HangarCamPeriodSetting
OPTIONS = HangarCamPeriodSetting.OPTIONS
HANGAR_CAM_PERIODS = {OPTIONS.TYPE0: 30, 
   OPTIONS.TYPE1: 45, 
   OPTIONS.TYPE2: 60}

def convertSettingToFeatures(value):
    selected = OPTIONS.HANGAR_CAM_TYPES[value]
    return HANGAR_CAM_PERIODS.get(selected, -1)