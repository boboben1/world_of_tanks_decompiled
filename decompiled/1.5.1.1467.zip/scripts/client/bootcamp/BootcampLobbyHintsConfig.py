# uncompyle6 version 3.3.3
# Python bytecode 2.7 (62211)
# Decompiled from: Python 2.7.13 (v2.7.13:a06454b1afa1, Dec 17 2016, 20:53:40) [MSC v.1500 64 bit (AMD64)]
# Embedded file name: scripts/client/bootcamp/BootcampLobbyHintsConfig.py
from gui.Scaleform.daapi.settings.views import VIEW_ALIAS

class BootcampLobbyHintsConfig:
    objects = {'InBattleRepairKit': {'viewAlias': VIEW_ALIAS.BOOTCAMP_BATTLE_PAGE, 
                             'path': 'consumablesPanel:index=slotIndex', 
                             'slotIndex': 3, 
                             'padding': {'left': 6, 'right': -6, 'top': 28, 'bottom': -6}}, 
       'InBattleHealKit': {'viewAlias': VIEW_ALIAS.BOOTCAMP_BATTLE_PAGE, 
                           'path': 'consumablesPanel:index=slotIndex', 
                           'slotIndex': 4, 
                           'padding': {'left': 6, 'right': -6, 'top': 28, 'bottom': -6}}, 
       'InBattleExtinguisher': {'viewAlias': VIEW_ALIAS.BOOTCAMP_BATTLE_PAGE, 
                                'path': 'consumablesPanel:index=slotIndex', 
                                'slotIndex': 5, 
                                'padding': {'left': 6, 'right': -6, 'top': 28, 'bottom': -6}}, 
       'Consumables': {'viewAlias': VIEW_ALIAS.BOOTCAMP_BATTLE_PAGE, 
                       'path': 'consumablesPanel', 
                       'padding': {'left': 7, 'right': -7, 'top': 16, 'bottom': -8}, 'customHint': 'BCHudHintUI'}, 
       'FragCorrelationBar': {'viewAlias': VIEW_ALIAS.BOOTCAMP_BATTLE_PAGE, 
                              'path': 'fragCorrelationBar', 
                              'padding': {'left': -100, 'right': 100, 'bottom': -4}, 'customHint': 'BCHudHintUI', 
                              'hideBorder': True}, 
       'Minimap': {'viewAlias': VIEW_ALIAS.BOOTCAMP_BATTLE_PAGE, 
                   'path': 'minimap.mapHit', 
                   'padding': {'left': -15, 'top': -15, 'right': 2, 'bottom': 2}, 'customHint': 'BCHudHintUI'}, 
       'FragCorrelationBarAppear': {'viewAlias': VIEW_ALIAS.BOOTCAMP_BATTLE_PAGE, 
                                    'path': 'fragCorrelationBar', 
                                    'padding': {'left': 340, 'right': -340, 'bottom': -4}, 'customHint': 'BCAppearHintUI'}, 
       'ConsumablesAppear': {'viewAlias': VIEW_ALIAS.BOOTCAMP_BATTLE_PAGE, 
                             'path': 'consumablesPanel', 
                             'padding': {'left': 7, 'right': -7, 'top': 16, 'bottom': -8}, 'customHint': 'BCAppearHintUI'}, 
       'MinimapAppear': {'viewAlias': VIEW_ALIAS.BOOTCAMP_BATTLE_PAGE, 
                         'path': 'minimap.background', 
                         'padding': {'left': 7, 'right': -7, 'top': 16, 'bottom': -8}, 'customHint': 'BCAppearHintUI'}, 
       'ConsumableSlot1': {'viewAlias': VIEW_ALIAS.BOOTCAMP_BATTLE_PAGE, 
                           'path': 'consumablesPanel:index=slotIndex.iconLoader', 
                           'slotIndex': 0}, 
       'ConsumableSlot4': {'viewAlias': VIEW_ALIAS.BOOTCAMP_BATTLE_PAGE, 
                           'path': 'consumablesPanel:index=slotIndex.iconLoader', 
                           'slotIndex': 3, 
                           'customHint': 'BCHudHintUI'}, 
       'ConsumableSlot5': {'viewAlias': VIEW_ALIAS.BOOTCAMP_BATTLE_PAGE, 
                           'path': 'consumablesPanel:index=slotIndex.iconLoader', 
                           'slotIndex': 4, 
                           'customHint': 'BCHudHintUI'}, 
       'ConsumableSlot6': {'viewAlias': VIEW_ALIAS.BOOTCAMP_BATTLE_PAGE, 
                           'path': 'consumablesPanel:index=slotIndex.iconLoader', 
                           'slotIndex': 5, 
                           'customHint': 'BCHudHintUI'}, 
       'DamagePanelHealthbar': {'viewAlias': VIEW_ALIAS.BOOTCAMP_BATTLE_PAGE, 
                                'path': 'damagePanel.healthBar'}, 
       'LoadingRightButton': {'viewAlias': VIEW_ALIAS.BOOTCAMP_INTRO_VIDEO, 
                              'path': 'btnRight', 
                              'customHint': 'BCHudHintUI'}, 
       'LoadingLeftButton': {'viewAlias': VIEW_ALIAS.BOOTCAMP_INTRO_VIDEO, 
                             'path': 'btnLeft', 
                             'customHint': 'BCHudHintUI'}, 
       'StartBattleButton': {'viewAlias': VIEW_ALIAS.BOOTCAMP_INTRO_VIDEO, 
                             'path': 'loadingProgress.btnSelect', 
                             'hideBorder': True}}

    def getItems(self):
        return self.objects


g_bootcampHintsConfig = BootcampLobbyHintsConfig()