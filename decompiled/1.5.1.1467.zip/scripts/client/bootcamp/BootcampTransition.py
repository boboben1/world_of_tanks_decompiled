# uncompyle6 version 3.3.3
# Python bytecode 2.7 (62211)
# Decompiled from: Python 2.7.13 (v2.7.13:a06454b1afa1, Dec 17 2016, 20:53:40) [MSC v.1500 64 bit (AMD64)]
# Embedded file name: scripts/client/bootcamp/BootcampTransition.py
from StartBootcampTransition import StartBootcampTransition
from debug_utils_bootcamp import LOG_DEBUG_DEV_BOOTCAMP

class BootcampTransition(object):
    _transitionWindow = None

    @classmethod
    def start(cls, name='bootcampTransitionsApp.swf'):
        if cls._transitionWindow:
            cls._transitionWindow.close()
            cls._transitionWindow = None
        cls._transitionWindow = StartBootcampTransition(name)
        cls._transitionWindow.active(True)
        return

    @classmethod
    def stop(cls):
        LOG_DEBUG_DEV_BOOTCAMP('TRANSITION_end', cls)
        if cls._transitionWindow:
            cls._transitionWindow.active(False)
            cls._transitionWindow.close()
            cls._transitionWindow = None
        return