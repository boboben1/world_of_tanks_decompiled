# uncompyle6 version 3.3.3
# Python bytecode 2.7 (62211)
# Decompiled from: Python 2.7.13 (v2.7.13:a06454b1afa1, Dec 17 2016, 20:53:40) [MSC v.1500 64 bit (AMD64)]
# Embedded file name: scripts/client/bootcamp/states/__init__.py


class STATE(object):
    INITIAL = 0
    BATTLE_PREPARING = 1
    IN_BATTLE = 2
    RESULT_SCREEN = 3
    IN_GARAGE = 4
    OUTRO_VIDEO = 5
    FINISHING = 6