# uncompyle6 version 3.3.3
# Python bytecode 2.7 (62211)
# Decompiled from: Python 2.7.13 (v2.7.13:a06454b1afa1, Dec 17 2016, 20:53:40) [MSC v.1500 64 bit (AMD64)]
# Embedded file name: scripts/client/gameplay/machine.py
import logging, BattleReplay
from constants import HAS_DEV_RESOURCES
from frameworks.state_machine import StateMachine
from gameplay import states
_logger = logging.getLogger(__name__)
_logger.addHandler(logging.NullHandler())

class GameplayStateMachine(StateMachine):
    __slots__ = ()

    @property
    def offline(self):
        return self.getChildByIndex(0)

    @property
    def online(self):
        return self.getChildByIndex(1)

    def configure(self):
        offline = states.OfflineState()
        offline.configure()
        online = states.OnlineState()
        online.configure(offline)
        self.addState(offline)
        self.addState(online)


class BattleReplayMachine(StateMachine):
    __slots__ = ()

    def configure(self):
        initialization = states.BattleReplayInitState()
        initialization.configure()
        playing = states.BattleReplayPlayingState()
        playing.configure(initialization)
        self.addState(initialization)
        self.addState(playing)

    def start(self, doValidate=True):
        super(BattleReplayMachine, self).start(doValidate)
        BattleReplay.g_replayCtrl.autoStartBattleReplay()


def create():
    if BattleReplay.g_replayCtrl.getAutoStartFileName():
        return BattleReplayMachine()
    if HAS_DEV_RESOURCES:
        try:
            from gui.development.dev_gameplay import DevGameplayStateMachine
        except ImportError:
            _logger.exception('Development state machine is not found')
            return GameplayStateMachine()

        return DevGameplayStateMachine()
    return GameplayStateMachine()