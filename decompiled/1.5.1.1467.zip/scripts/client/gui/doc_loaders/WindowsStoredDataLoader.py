# uncompyle6 version 3.3.3
# Python bytecode 2.7 (62211)
# Decompiled from: Python 2.7.13 (v2.7.13:a06454b1afa1, Dec 17 2016, 20:53:40) [MSC v.1500 64 bit (AMD64)]
# Embedded file name: scripts/client/gui/doc_loaders/WindowsStoredDataLoader.py
import base64, cPickle, Settings
from debug_utils import LOG_ERROR, LOG_CURRENT_EXCEPTION

class WindowsStoredDataLoader(object):

    def __init__(self, rev, maxRecordLen, defMask):
        super(WindowsStoredDataLoader, self).__init__()
        self.__rev = rev
        self.__maxRecordLen = maxRecordLen
        self.__defMask = defMask

    def load(self):
        if Settings.g_instance is None:
            LOG_ERROR('Settings is not defined, can not load data')
            return (
             self.__defMask, [])
        section = Settings.g_instance.userPrefs[Settings.KEY_WINDOWS_STORED_DATA]
        if section is None:
            return (self.__defMask, [])
        mask = section.readInt('mask', self.__defMask)
        rev = section.readInt('rev', self.__rev)
        records = []
        if rev == self.__rev:
            dataSec = section['records']

            def decode(value):
                try:
                    return cPickle.loads(base64.b64decode(value))
                except TypeError:
                    LOG_CURRENT_EXCEPTION()
                    return

                return

            if dataSec is not None:
                for _, subSec in dataSec.items():
                    record = decode(subSec.asString)
                    if record:
                        records.append(record)

        return (
         mask, records)

    def flush(self, mask, records):
        if Settings.g_instance is None:
            LOG_ERROR('Settings is not defined, can not flush data')
            return
        userPrefs = Settings.g_instance.userPrefs
        section = userPrefs[Settings.KEY_WINDOWS_STORED_DATA]
        if section is None:
            section = userPrefs.createSection(Settings.KEY_WINDOWS_STORED_DATA)
        section.writeInt('mask', mask)
        section.writeInt('rev', self.__rev)
        section.deleteSection('records')
        if records:
            dataSec = section.createSection('records')
            records = records[:self.__maxRecordLen]

            def encode(value):
                return base64.b64encode(cPickle.dumps(value))

            dataSec.writeStrings('record', map(encode, records))
        Settings.g_instance.save()
        return