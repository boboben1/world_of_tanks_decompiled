# uncompyle6 version 3.3.3
# Python bytecode 2.7 (62211)
# Decompiled from: Python 2.7.13 (v2.7.13:a06454b1afa1, Dec 17 2016, 20:53:40) [MSC v.1500 64 bit (AMD64)]
# Embedded file name: scripts/client/bwobsolete_helpers/Caps.py
CAP_NONE = 0
CAP_NEVER = 0
CAP_CAN_HIT = 1
CAP_CAN_USE = 2
CAP_CAN_HACK = 3
CAP_CAN_FEED = 4
CAP_CAN_STUN = 5
CAP_CAN_INHIBIT = 6
CAP_CAN_BUG = 7
CAP_CAN_TAKE_DOWN = 8
CAP_AFTER_LAST = 9
CAP_CAN_REVIVE = 10
CAP_CAN_MELEE = 11
CAP_CAN_SHONK = 12