# uncompyle6 version 3.3.3
# Python bytecode 2.7 (62211)
# Decompiled from: Python 2.7.13 (v2.7.13:a06454b1afa1, Dec 17 2016, 20:53:40) [MSC v.1500 64 bit (AMD64)]
# Embedded file name: scripts/client/AvatarInputHandler/subfilters_constants.py


class AVATAR_SUBFILTERS(object):
    CAMERA_SHOT_POINT = 0
    CAMERA_ARTY_SHOT_POINT = 1
    CAMERA_ARTY_TRANSLATION = 2
    CAMERA_ARTY_ROTATION = 3


class FILTER_INTERPOLATION_TYPE(object):
    LINEAR = 0
    SLERP_OF_CARTESIAN = 1
    ANGLE_RADIANS = 2
    SPHERICAL_RADIANS = 3