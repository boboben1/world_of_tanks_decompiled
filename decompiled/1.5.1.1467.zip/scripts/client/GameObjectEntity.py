# uncompyle6 version 3.3.3
# Python bytecode 2.7 (62211)
# Decompiled from: Python 2.7.13 (v2.7.13:a06454b1afa1, Dec 17 2016, 20:53:40) [MSC v.1500 64 bit (AMD64)]
# Embedded file name: scripts/client/GameObjectEntity.py
import importlib, BigWorld, Svarog, GenericComponents, NetworkComponents
from debug_utils import LOG_DEBUG

class GameObjectEntity(BigWorld.Entity):
    ENFORCE_RELOAD = False

    def onEnterWorld(self, prereqs):
        if not self.prefab:
            return
        self.loadFromScript(self.prefab)

    def loadFromScript(self, script, doReload=False):
        doReload = doReload or GameObjectEntity.ENFORCE_RELOAD
        self.gameObject = Svarog.GameObject(self.spaceID)
        self.gameObject.activate()
        self.gameObject.createComponent(GenericComponents.TransformComponent, self.matrix)
        self.gameObject.createComponent(NetworkComponents.NetworkEntity, self)
        if not script:
            return
        module = importlib.import_module(script)
        if doReload:
            LOG_DEBUG('reloading')
            reload(module)
        module.spaceID = self.spaceID
        module.buildCommon(self.gameObject)
        module.buildClient(self.gameObject)

    def onLeaveWorld(self):
        self.gameObject = None
        return

    def reload(self):
        self.loadFromScript(self.prefab, True)